gsap.set(".circle-wrap", {opacity: 0.8, scale: 3});

const timeline = gsap.timeline({  })
	.to(".animate-logo", { scale: 0.5,})
	.to(".circle-logo", {scale: 2.8,}, 0)
	.from(".circle-wrap", {scale:0, duration: 2, transformOrigin: '50% 50%',})
	.to(".animate-logo__line", {opacity: 1 scale: 0.5})
	.to(".animate-logo__box-circle", {rotate: 720, scale:0.8, duration: 20})
	.to(".animate-logo__nine", {opacity: 1, duration: 1})


gsap.registerPlugin(ScrollTrigger);

ScrollTrigger.create({
  animation: timeline, 
  trigger: ".logo__wrap",
  start: "0% 0%",
	end: "100%+=" + timeline.duration() * 10 + "0%",
  scrub: 5, 
	pin: '.logo__wrap',
	markers: true,

});




